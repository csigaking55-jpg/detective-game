// Éhes béka játék

let canvas = document.getElementById('c');
let ctx = canvas.getContext('2d');

// a canvas legyen akkora mint az ablak
canvas.width = canvas.clientWidth;
canvas.height = canvas.clientHeight;

let szelesseg = canvas.width;
let magassag = canvas.height;

// változók
let bekaX = szelesseg / 2;
let bekaY = magassag - 70;
let pont = 0;
let elet = 3;
let dolgok = [];
let megy = false;
let balra = false;
let jobbra = false;

// egérrel mozog a béka
canvas.addEventListener('mousemove', function (e) {
  bekaX = e.clientX;
});

// ujjal is lehet (telefonon)
canvas.addEventListener('touchmove', function (e) {
  bekaX = e.touches[0].clientX;
});

// nyilakkal is lehet
document.addEventListener('keydown', function (e) {
  if (e.key == 'ArrowLeft') balra = true;
  if (e.key == 'ArrowRight') jobbra = true;
});
document.addEventListener('keyup', function (e) {
  if (e.key == 'ArrowLeft') balra = false;
  if (e.key == 'ArrowRight') jobbra = false;
});

// start gomb
document.getElementById('start').addEventListener('click', function () {
  pont = 0;
  elet = 3;
  dolgok = [];
  bekaX = szelesseg / 2;
  kiirás();
  document.getElementById('overlay').classList.add('hidden');
  megy = true;
});

// kiírja a pontot és az életet
function kiirás() {
  document.getElementById('score').textContent = '🪰 ' + pont;
  document.getElementById('lives').textContent = '❤️'.repeat(elet) + '🤍'.repeat(3 - elet);
}

// új dolog ami leesik
function ujDolog() {
  let fajta = '🪰';
  let szam = Math.random();
  if (szam < 0.1) {
    fajta = '⭐';
  } else if (szam < 0.3) {
    fajta = '🐝';
  }

  dolgok.push({
    fajta: fajta,
    x: Math.random() * (szelesseg - 60) + 30,
    y: -30,
    sebesseg: 3 + Math.random() * 2 + pont / 10
  });
}

function vege() {
  megy = false;
  alert('Vége a játéknak! Pontjaid: ' + pont);
  document.getElementById('overlay').classList.remove('hidden');
}

// ez fut le újra és újra
function jatek() {
  if (megy == true) {
    // béka mozgatása nyilakkal
    if (balra) bekaX = bekaX - 10;
    if (jobbra) bekaX = bekaX + 10;
    if (bekaX < 30) bekaX = 30;
    if (bekaX > szelesseg - 30) bekaX = szelesseg - 30;

    // néha jön egy új dolog
    if (Math.random() < 0.03) {
      ujDolog();
    }

    let maradnak = [];
    for (let i = 0; i < dolgok.length; i++) {
      let d = dolgok[i];
      d.y = d.y + d.sebesseg;

      // elkapta a béka?
      if (Math.abs(d.x - bekaX) < 40 && Math.abs(d.y - bekaY) < 30) {
        if (d.fajta == '🐝') {
          elet = elet - 1;
        } else if (d.fajta == '⭐') {
          pont = pont + 5;
        } else {
          pont = pont + 1;
        }
        kiirás();
      } else if (d.y < magassag + 40) {
        maradnak.push(d);
      }
    }
    dolgok = maradnak;

    if (elet <= 0) {
      vege();
    }
  }

  rajzol();
}

function rajzol() {
  // ég
  ctx.fillStyle = '#BDE8F5';
  ctx.fillRect(0, 0, szelesseg, magassag);

  // tó
  ctx.fillStyle = '#3FA38C';
  ctx.fillRect(0, magassag * 0.72, szelesseg, magassag);

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // béka
  ctx.font = '64px serif';
  ctx.fillText('🐸', bekaX, bekaY);

  // leeső dolgok
  ctx.font = '38px serif';
  for (let i = 0; i < dolgok.length; i++) {
    ctx.fillText(dolgok[i].fajta, dolgok[i].x, dolgok[i].y);
  }
}

setInterval(jatek, 16);
